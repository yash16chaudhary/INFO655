import React from 'react';
import { render } from '@testing-library/react';
import '@testing-library/jest-dom'; // Import the Jest-DOM extension

import Status from '../Status';

test('renders Status component with valid text', () => {
  const testStatusText = 'Test Status';
  const { getByText } = render(<Status statusText={testStatusText} />);

  // Check if the rendered component contains the expected text
  expect(getByText(testStatusText)).toBeInTheDocument();
});
