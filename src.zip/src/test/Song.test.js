import '@testing-library/jest-dom'
import React from 'react';
import { render, screen } from '@testing-library/react';
import Song from '../Song';

test('renders Song component with string year as "Unknown"', () => {
  const testData = {
    title: 'Test Song',
    artist: 'Test Artist',
    year: 'InvalidYear',
  };

  render(<Song title={testData.title} artist={testData.artist} year={testData.year} />);

  expect(screen.getByText(testData.title)).toBeInTheDocument();
  expect(screen.getByText(`Artist: ${testData.artist}`)).toBeInTheDocument();
  // You can check the absence of the 'Year' element for string year
  expect(screen.queryByText('Year:')).toBeNull();
});
test('renders Song component with provided title, artist, and year', () => {
    const testData = {
      title: 'Back In Black',
      artist: 'acdc',
      year: 'Yash',
    };
  
    render(<Song title={testData.title} artist={testData.artist} year={testData.year} />);
  
    // Check if the component renders the provided title, artist, and year
    expect(screen.getByText(testData.title)).toBeInTheDocument();
    expect(screen.getByText(`Artist: ${testData.artist}`)).toBeInTheDocument();
    expect(screen.getByText(`Year: ${testData.year}`)).toBeInTheDocument();
  });

  test('renders Song component with provided title, artist, and year', () => {
    const testData = {
      title: 2002,
      artist: 'acdc',
      year: 'Yash',
    };
  
    render(<Song title={testData.title} artist={testData.artist} year={testData.year} />);
  
    // Check if the component renders the provided title, artist, and year
    expect(screen.getByText(testData.title)).toBeInTheDocument();
    expect(screen.getByText(`Artist: ${testData.artist}`)).toBeInTheDocument();
    expect(screen.getByText(`Year: ${testData.year}`)).toBeInTheDocument();
  });