import React from 'react';
import { render, fireEvent } from '@testing-library/react';
import PrevButton from '../PrevButton';
import '@testing-library/jest-dom';

test('renders PrevButton component', () => {
  const { getByText } = render(<PrevButton onClick={() => {}} />);
  const prevButton = getByText('Prev');
  expect(prevButton).toBeInTheDocument();
});

test('PrevButton has correct text', () => {
  const { getByText } = render(<PrevButton onClick={() => {}} />);
  const prevButton = getByText('Prev');
  expect(prevButton).toHaveTextContent('Prev');
});

test('calls onClick when PrevButton is clicked', () => {
  const onClickMock = jest.fn();
  const { getByText } = render(<PrevButton onClick={onClickMock} />);
  
  fireEvent.click(getByText('Prev'));
  
  expect(onClickMock).toHaveBeenCalled();
});
